#include <gtest/gtest.h>

namespace Test {

TEST(host_barrier, openmp) {}

}  // namespace Test
