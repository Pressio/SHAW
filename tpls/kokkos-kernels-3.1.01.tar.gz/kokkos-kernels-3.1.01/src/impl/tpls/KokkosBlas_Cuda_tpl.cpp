#include <Kokkos_Core.hpp>
#include <KokkosKernels_config.h>
#include<KokkosBlas_Cuda_tpl.hpp>
